#!/bin/bash
MYDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" > /dev/null && pwd )"
echo "[Desktop Entry]
Name=HELI
Comment=
Icon=$MYDIR/HELI_icon.png
Exec=\"$MYDIR/HELI\"
Type=Application
Encoding=UTF-8
Terminal=false
Categories=None;" > "$HOME/Desktop/HELI.desktop"
chmod +x "$HOME/Desktop/HELI.desktop"
